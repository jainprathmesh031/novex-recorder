# Proguard rules for Novex Recorder
-keep class com.novex.recorder.service.** { *; }
-keep class com.novex.recorder.encoder.** { *; }
-keep class com.novex.recorder.audio.** { *; }
-keep class com.novex.recorder.data.** { *; }
-dontwarn android.media.**
