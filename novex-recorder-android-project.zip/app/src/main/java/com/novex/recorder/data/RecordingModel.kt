package com.novex.recorder.data

import android.net.Uri

data class RecordingItem(
    val id: Long,
    val title: String,
    val uri: Uri,
    val path: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateModifiedMs: Long,
    val width: Int,
    val height: Int,
    val bitrateBps: Long,
    val mimeType: String
) {
    val durationFormatted: String
        get() {
            val totalSec = durationMs / 1000
            val min = totalSec / 60
            val sec = totalSec % 60
            val hrs = min / 60
            return if (hrs > 0) {
                String.format("%02d:%02d:%02d", hrs, min % 60, sec)
            } else {
                String.format("%02d:%02d", min, sec)
            }
        }

    val sizeFormatted: String
        get() {
            val mb = sizeBytes / (1024.0 * 1024.0)
            return if (mb >= 1024) {
                String.format("%.2f GB", mb / 1024.0)
            } else {
                String.format("%.1f MB", mb)
            }
        }

    val resolutionLabel: String
        get() = "${width}x${height}"
}
