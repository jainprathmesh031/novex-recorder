package com.novex.recorder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novex.recorder.data.CaptureResolution
import com.novex.recorder.data.CodecDetector
import com.novex.recorder.data.EncoderCapabilityReport
import com.novex.recorder.ui.components.*
import com.novex.recorder.ui.theme.Novex

@Composable
fun InspectorScreen(report: EncoderCapabilityReport, landscape: Boolean, onBack: () -> Unit) {
    val c = Novex.c
    val matrix = remember(landscape) { CodecDetector.matrix(landscape, report.screenWidth, report.screenHeight) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Back", tint = c.text) }
                Column {
                    Text("INSPECTOR", color = c.text, fontWeight = FontWeight.Black, fontSize = 26.sp, letterSpacing = 3.sp)
                    Text("What your phone's encoders really support", color = c.textDim, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            GlassCard {
                SectionTitle("DEVICE", Icons.Rounded.Memory)
                Row2("Model", report.deviceModel)
                Row2("Screen", "${report.screenWidth} x ${report.screenHeight}")
                Row2("H.264 encoder", report.avcEncoder + if (report.avcHardware) "  (HW)" else "  (SW)")
                Row2("H.264 max", "${report.avcMaxWidth}x${report.avcMaxHeight} • ${report.avcMaxFps} fps • ${report.avcBitrateMaxMbps} Mbps")
                Row2("HEVC encoder", report.hevcEncoder + if (report.hevcHardware) "  (HW)" else "  (SW)")
                Row2("HEVC max", "${report.hevcMaxWidth}x${report.hevcMaxHeight} • ${report.hevcMaxFps} fps")
            }
        }
        item {
            GlassCard {
                SectionTitle("SUPPORT MATRIX", Icons.Rounded.Memory)
                Text(
                    "Left dot = H.264, right dot = HEVC. Filled = supported at that size & fps.",
                    color = c.textDim, style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    Spacer(Modifier.weight(1.6f))
                    CodecDetector.FPS_OPTIONS.forEach {
                        Text("$it", color = c.accent, fontWeight = FontWeight.Black, fontSize = 13.sp,
                            textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    }
                }
                Spacer(Modifier.height(6.dp))
                matrix.forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1.6f)) {
                            Text(row.resolution.label, color = c.text, fontWeight = FontWeight.Black, fontSize = 15.sp)
                            Text("${row.width}x${row.height}", color = c.textDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        CodecDetector.FPS_OPTIONS.forEach { f ->
                            val cell = row.cells[f]
                            Text(
                                (if (cell?.avc == true) "●" else "○") + " " + (if (cell?.hevc == true) "●" else "○"),
                                color = if (cell?.avc == true || cell?.hevc == true) c.ok else c.textDim,
                                fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Recordings above your screen's ${minOf(report.screenWidth, report.screenHeight)}p are upscaled (smoother, bigger file, not extra detail). " +
                            "Actual fps also depends on the app you record producing frames.",
                    color = c.textDim, style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun Row2(label: String, value: String) {
    val c = Novex.c
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = c.textDim, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
        Text(value, color = c.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace, textAlign = TextAlign.End, modifier = Modifier.weight(1.2f))
    }
}
