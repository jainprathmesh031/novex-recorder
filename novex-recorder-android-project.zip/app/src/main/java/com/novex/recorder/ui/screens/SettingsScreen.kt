package com.novex.recorder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novex.recorder.data.*
import com.novex.recorder.ui.components.*
import com.novex.recorder.ui.theme.Novex

@Composable
fun SettingsScreen(
    config: RecordingConfig,
    onChange: (RecordingConfig) -> Unit,
    onOpenInspector: () -> Unit,
    onOpenInstagram: () -> Unit
) {
    val c = Novex.c
    val ctx = LocalContext.current
    val (sw, sh) = remember { CodecDetector.screenSize(ctx) }

    // Status of every resolution / fps for THIS phone
    val resStatus = remember(config.frameRate, config.codecPref, config.landscape) {
        CaptureResolution.values().associateWith { CodecDetector.statusFor(config, it, config.frameRate, sw, sh) }
    }
    val fpsStatus = remember(config.resolution, config.codecPref, config.landscape) {
        CodecDetector.FPS_OPTIONS.associateWith { CodecDetector.statusFor(config, config.resolution, it, sw, sh) }
    }
    fun statusColor(s: String): Color = when (s) {
        "NATIVE" -> c.ok
        "UPSCALED" -> c.accent2
        else -> c.warn
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)
    ) {
        item {
            Text("ENGINE", color = c.text, fontWeight = FontWeight.Black, fontSize = 30.sp, letterSpacing = 3.sp)
            Text("Every option is checked against your phone's real encoder.", color = c.textDim, style = MaterialTheme.typography.bodySmall)
        }

        // ── Video
        item {
            GlassCard {
                SectionTitle("VIDEO", Icons.Rounded.Videocam)

                FieldLabel("Resolution", "UPSCALED = bigger than your screen's ${minOf(sw, sh)}p; recorded by scaling up. FALLBACK = encoder can't do it, nearest mode is used.")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CaptureResolution.values().forEach { r ->
                        val st = resStatus[r] ?: "FALLBACK"
                        ChoiceChip(r.label, config.resolution == r, Modifier.weight(1f), st, statusColor(st)) {
                            onChange(config.copy(resolution = r))
                        }
                    }
                }

                Spacer(Modifier.height(18.dp))
                FieldLabel("Frame rate", "No cap: all four are selectable. If your encoder can't hit it at this resolution the app steps down automatically.")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CodecDetector.FPS_OPTIONS.forEach { f ->
                        val st = fpsStatus[f] ?: "FALLBACK"
                        ChoiceChip("$f", config.frameRate == f, Modifier.weight(1f), st, statusColor(st)) {
                            onChange(config.copy(frameRate = f))
                        }
                    }
                }

                Spacer(Modifier.height(18.dp))
                FieldLabel("Video codec", "Auto tries H.264 then HEVC. HEVC unlocks higher resolutions on many phones.")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CodecPref.values().forEach { p ->
                        ChoiceChip(p.label, config.codecPref == p, Modifier.weight(1f)) { onChange(config.copy(codecPref = p)) }
                    }
                }

                Spacer(Modifier.height(18.dp))
                FieldLabel("Orientation", "Auto matches your screen at the moment recording starts (no zoomed-out bars). Pick Landscape for games if you start from the app.")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChoiceChip("Auto", config.orientationAuto, Modifier.weight(1f)) { onChange(config.copy(orientationAuto = true)) }
                    ChoiceChip("Landscape", !config.orientationAuto && config.landscape, Modifier.weight(1f)) {
                        onChange(config.copy(orientationAuto = false, landscape = true))
                    }
                    ChoiceChip("Portrait", !config.orientationAuto && !config.landscape, Modifier.weight(1f)) {
                        onChange(config.copy(orientationAuto = false, landscape = false))
                    }
                }
            }
        }

        // ── Bitrate
        item {
            GlassCard {
                SectionTitle("BITRATE", Icons.Rounded.Speed)
                ToggleRow(
                    "Auto bitrate",
                    "Picks the best bitrate for the resolution, fps and codec you chose.",
                    config.bitrateAuto
                ) { onChange(config.copy(bitrateAuto = it)) }
                if (!config.bitrateAuto) {
                    Spacer(Modifier.height(8.dp))
                    Text("${config.videoBitrateMbps} Mbps", color = c.text, fontWeight = FontWeight.Black, fontSize = 22.sp)
                    Text(
                        "≈ ${CodecDetector.estimateMbPerMinute(config.videoBitrateMbps, config.audioBitrateKbps)} MB per minute",
                        color = c.accent, fontFamily = FontFamily.Monospace, fontSize = 12.sp
                    )
                    Slider(
                        value = config.videoBitrateMbps.toFloat(),
                        onValueChange = { onChange(config.copy(videoBitrateMbps = it.toInt())) },
                        valueRange = 4f..150f,
                        colors = SliderDefaults.colors(thumbColor = c.accent, activeTrackColor = c.accent, inactiveTrackColor = c.border)
                    )
                    Text("Clamped to what your encoder allows.", color = c.textDim, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        // ── Audio
        item {
            GlassCard {
                SectionTitle("AUDIO", Icons.Rounded.GraphicEq)
                ToggleRow("Phone sound", "Game and media audio captured internally. No mic echo.", config.captureInternalAudio) {
                    onChange(config.copy(captureInternalAudio = it))
                }
                HorizontalDivider(color = c.border, modifier = Modifier.padding(vertical = 8.dp))
                ToggleRow("Microphone", "Voice, comms and commentary.", config.captureMicAudio) {
                    onChange(config.copy(captureMicAudio = it))
                }
                Spacer(Modifier.height(12.dp))
                FieldLabel("Audio tracks", config.audioMuxingMode.description)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AudioMuxingMode.values().forEach { m ->
                        ChoiceChip(
                            if (m == AudioMuxingMode.SEPARATE_TRACKS) "Separate" else "Mixed",
                            config.audioMuxingMode == m, Modifier.weight(1f)
                        ) { onChange(config.copy(audioMuxingMode = m)) }
                    }
                }
                Text("You can also switch each source on/off live while recording.", color = c.textDim, style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 10.dp))
            }
        }

        // ── Controls
        item {
            GlassCard {
                SectionTitle("CONTROLS", Icons.Rounded.Layers)
                ToggleRow("Floating controls", "Draggable pill: pause, mic, phone sound, stop.", config.showFloatingOverlay) {
                    onChange(config.copy(showFloatingOverlay = it))
                }
                HorizontalDivider(color = c.border, modifier = Modifier.padding(vertical = 8.dp))
                ToggleRow(
                    "Stealth mode",
                    "Controls collapse into a near-invisible dot so they barely appear in your video. Tap the dot to expand.",
                    config.stealthOverlay
                ) { onChange(config.copy(stealthOverlay = it)) }
                Spacer(Modifier.height(12.dp))
                FieldLabel("Countdown")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0, 3, 5).forEach { s ->
                        ChoiceChip(if (s == 0) "Off" else "${s}s", config.countdownSeconds == s, Modifier.weight(1f)) {
                            onChange(config.copy(countdownSeconds = s))
                        }
                    }
                }
            }
        }

        // ── More
        item {
            GlassCard {
                SectionTitle("MORE", Icons.Rounded.AutoAwesome)
                GradientButton("ENCODER INSPECTOR", Icons.Rounded.Memory, Modifier.fillMaxWidth(), onClick = onOpenInspector)
                Spacer(Modifier.height(10.dp))
                GradientButton(
                    "FOLLOW @INSIDE.NOVEX", Icons.Rounded.CameraAlt, Modifier.fillMaxWidth(),
                    colors = listOf(Color(0xFF833AB4), Color(0xFFFD1D1D), Color(0xFFFCB045)), onClick = onOpenInstagram
                )
            }
        }
    }
}
