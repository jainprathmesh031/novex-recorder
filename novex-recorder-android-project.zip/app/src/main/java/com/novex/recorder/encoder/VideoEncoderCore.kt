package com.novex.recorder.encoder

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.os.Bundle
import android.util.Log
import android.view.Surface
import com.novex.recorder.data.CapturePlan
import com.novex.recorder.data.VideoCodec
import java.util.concurrent.atomic.AtomicBoolean

class VideoEncoderCore(
    private val plan: CapturePlan,
    private val muxerManager: MuxerManager
) {
    private val width = plan.width
    private val height = plan.height
    private val frameRate = plan.fps
    private val bitrateBps = plan.bitrateBps
    /** Called (off the main thread) if the encoder dies mid-recording. */
    var onFatal: (() -> Unit)? = null

    companion object {
        private const val TAG = "NovexVideoEncoder"
        private const val TIMEOUT_USEC = 10000L
    }

    private var mediaCodec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var trackIndex = -1
    private val isRunning = AtomicBoolean(false)
    private val isPaused = AtomicBoolean(false)
    private val needKeyFrame = AtomicBoolean(false)
    private var workerThread: Thread? = null

    @Volatile private var startUs: Long = 0
    @Volatile private var pauseOffsetUs: Long = 0
    private var pauseStartUs: Long = 0
    private var lastPtsUs: Long = -1

    private fun nowUs() = System.nanoTime() / 1000L

    fun prepare(): Surface {
        val MIME_TYPE = plan.codec.mime
        fun buildFormat(withProfile: Boolean) = MediaFormat.createVideoFormat(MIME_TYPE, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrateBps)
            setInteger(MediaFormat.KEY_FRAME_RATE, frameRate)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            // Real-time priority + operating rate help the Qualcomm encoder sustain high FPS
            setInteger(MediaFormat.KEY_PRIORITY, 0)
            setInteger(MediaFormat.KEY_OPERATING_RATE, frameRate)
            if (withProfile) {
                // No explicit level: the codec picks the right one for size * fps
                setInteger(
                    MediaFormat.KEY_PROFILE,
                    if (plan.codec == VideoCodec.HEVC) MediaCodecInfo.CodecProfileLevel.HEVCProfileMain
                    else MediaCodecInfo.CodecProfileLevel.AVCProfileHigh
                )
            }
        }

        var lastError: Exception? = null
        for (withProfile in listOf(true, false)) {
            val codec = plan.encoderName?.let { MediaCodec.createByCodecName(it) }
                ?: MediaCodec.createEncoderByType(MIME_TYPE)
            try {
                codec.configure(buildFormat(withProfile), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                val surface = codec.createInputSurface()
                codec.start()
                mediaCodec = codec
                inputSurface = surface
                return surface
            } catch (e: Exception) {
                Log.w(TAG, "Encoder configure failed (profile=$withProfile)", e)
                lastError = e
                try { codec.release() } catch (_: Exception) {}
            }
        }
        throw IllegalStateException("Hardware encoder rejected ${width}x$height @ $frameRate fps", lastError)
    }

    fun start() {
        if (isRunning.getAndSet(true)) return
        startUs = nowUs()
        workerThread = Thread({ drainEncoder() }, "Novex-VideoEncoderThread").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun startTimeUs(): Long = startUs

    fun pause() {
        if (isPaused.compareAndSet(false, true)) pauseStartUs = nowUs()
    }

    fun resume() {
        if (isPaused.get()) {
            pauseOffsetUs += nowUs() - pauseStartUs
            needKeyFrame.set(true) // drop frames until a clean keyframe after resume
            try {
                mediaCodec?.setParameters(Bundle().apply {
                    putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
                })
            } catch (e: Exception) {
                Log.e(TAG, "Failed to request sync frame", e)
            }
            isPaused.set(false)
        }
    }

    private fun drainEncoder() {
        val codec = mediaCodec ?: return
        val info = MediaCodec.BufferInfo()
        try {
            while (true) {
                val index = codec.dequeueOutputBuffer(info, TIMEOUT_USEC)
                if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    trackIndex = muxerManager.registerTrack(codec.outputFormat)
                } else if (index >= 0) {
                    val data = codec.getOutputBuffer(index)
                    val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                    val isKey = (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
                    if (data != null && trackIndex >= 0 && !isConfig && info.size > 0 && !isPaused.get()) {
                        if (needKeyFrame.get() && isKey) needKeyFrame.set(false)
                        if (!needKeyFrame.get()) {
                            // Codec PTS = surface capture time (CLOCK_MONOTONIC), same base as System.nanoTime()
                            var pts = info.presentationTimeUs - startUs - pauseOffsetUs
                            if (pts <= lastPtsUs) pts = lastPtsUs + 1
                            if (pts < 0) pts = 0
                            lastPtsUs = pts
                            info.presentationTimeUs = pts
                            muxerManager.writeSampleData(trackIndex, data, info)
                        }
                    }
                    codec.releaseOutputBuffer(index, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                } else if (index == MediaCodec.INFO_TRY_AGAIN_LATER && !isRunning.get()) {
                    break
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception in video drain loop", e)
            if (isRunning.get()) onFatal?.invoke()
        }
    }

    fun stop() {
        if (!isRunning.getAndSet(false)) {
            release()
            return
        }
        try {
            mediaCodec?.signalEndOfInputStream()
            workerThread?.join(1500)
        } catch (e: Exception) {
            Log.e(TAG, "Error signaling EOS", e)
        } finally {
            release()
        }
    }

    private fun release() {
        try {
            mediaCodec?.stop()
            mediaCodec?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing video codec", e)
        } finally {
            mediaCodec = null
            inputSurface?.release()
            inputSurface = null
        }
    }
}
