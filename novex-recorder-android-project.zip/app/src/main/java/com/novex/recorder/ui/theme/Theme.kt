package com.novex.recorder.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

@Composable
fun NovexRecorderTheme(palette: NovexPalette, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = palette.accent,
        secondary = palette.accent2,
        tertiary = palette.record,
        background = palette.bgBottom,
        surface = palette.surface,
        onPrimary = palette.bgBottom,
        onSecondary = palette.text,
        onBackground = palette.text,
        onSurface = palette.text
    )
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            window?.let {
                it.statusBarColor = palette.bgTop.toArgb()
                it.navigationBarColor = palette.bgBottom.toArgb()
                WindowCompat.getInsetsController(it, view).isAppearanceLightStatusBars = false
            }
        }
    }
    CompositionLocalProvider(LocalNovex provides palette) {
        MaterialTheme(colorScheme = scheme, typography = NovexTypography, content = content)
    }
}
