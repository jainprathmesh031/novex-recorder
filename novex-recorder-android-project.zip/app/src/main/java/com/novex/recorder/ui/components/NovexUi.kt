package com.novex.recorder.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novex.recorder.ui.theme.Novex

@Composable
fun Modifier.novexBackdrop(): Modifier {
    val c = Novex.c
    return this.background(
        Brush.verticalGradient(listOf(c.bgTop, c.bgBottom))
    )
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    padding: Dp = 16.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val c = Novex.c
    val shape = RoundedCornerShape(22.dp)
    var m = modifier
        .fillMaxWidth()
        .clip(shape)
        .background(Brush.linearGradient(listOf(c.surfaceHigh.copy(alpha = 0.9f), c.surface)))
        .border(BorderStroke(1.dp, Brush.linearGradient(listOf(c.accent.copy(alpha = 0.55f), c.border, c.accent2.copy(alpha = 0.35f)))), shape)
    if (onClick != null) m = m.clickable { onClick() }
    Column(modifier = m.padding(padding), content = content)
}

@Composable
fun SectionTitle(text: String, icon: ImageVector, modifier: Modifier = Modifier) {
    val c = Novex.c
    Row(modifier = modifier.padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier.size(28.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(c.accent, c.accent2))),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.labelLarge, color = c.text, letterSpacing = 1.6.sp)
    }
}

@Composable
fun FieldLabel(text: String, hint: String? = null) {
    val c = Novex.c
    Text(text, style = MaterialTheme.typography.titleMedium, color = c.text)
    if (hint != null) Text(hint, style = MaterialTheme.typography.bodySmall, color = c.textDim)
    Spacer(Modifier.height(10.dp))
}

@Composable
fun Tag(text: String, color: Color, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = color,
        fontSize = 9.sp,
        fontWeight = FontWeight.Black,
        fontFamily = FontFamily.Monospace,
        letterSpacing = 0.8.sp,
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    )
}

/** Equal-width selectable chip with a big label and a small status line. */
@Composable
fun ChoiceChip(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    sub: String? = null,
    subColor: Color = Color.Unspecified,
    onClick: () -> Unit
) {
    val c = Novex.c
    val shape = RoundedCornerShape(16.dp)
    val bg = if (selected) Brush.linearGradient(listOf(c.accent.copy(alpha = 0.35f), c.accent2.copy(alpha = 0.22f)))
    else Brush.linearGradient(listOf(c.surface, c.surface))
    Column(
        modifier = modifier
            .clip(shape)
            .background(bg)
            .border(BorderStroke(1.2.dp, if (selected) c.accent else c.border), shape)
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            label, color = if (selected) c.text else c.textDim,
            fontWeight = FontWeight.Black, fontSize = 18.sp, textAlign = TextAlign.Center, maxLines = 1
        )
        if (sub != null) {
            Spacer(Modifier.height(3.dp))
            Text(
                sub, color = if (subColor == Color.Unspecified) c.textDim else subColor,
                fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                letterSpacing = 0.6.sp, maxLines = 1
            )
        }
    }
}

@Composable
fun ToggleRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = Novex.c
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = c.text)
            Spacer(Modifier.height(2.dp))
            Text(desc, style = MaterialTheme.typography.bodySmall, color = c.textDim)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White, checkedTrackColor = c.accent,
                uncheckedThumbColor = c.textDim, uncheckedTrackColor = c.surface,
                uncheckedBorderColor = c.border
            )
        )
    }
}

@Composable
fun GradientButton(
    text: String,
    icon: ImageVector?,
    modifier: Modifier = Modifier,
    colors: List<Color>? = null,
    onClick: () -> Unit
) {
    val c = Novex.c
    val shape = RoundedCornerShape(18.dp)
    Row(
        modifier = modifier
            .clip(shape)
            .background(Brush.horizontalGradient(colors ?: listOf(c.accent, c.accent2)))
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 15.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
        }
        Text(text, color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp, letterSpacing = 1.2.sp, maxLines = 1)
    }
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    val c = Novex.c
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(c.surface)
            .border(BorderStroke(1.dp, c.border), shape)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = c.textDim)
        Spacer(Modifier.height(4.dp))
        Text(value, color = c.text, fontWeight = FontWeight.Black, fontSize = 20.sp, maxLines = 1)
    }
}

@Composable
fun StatusDot(color: Color, size: Dp = 8.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(color))
}
