package com.novex.recorder.data

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class RecordingRepository(private val context: Context) {

    suspend fun getRecordings(): List<RecordingItem> = withContext(Dispatchers.IO) {
        val list = mutableListOf<RecordingItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.RELATIVE_PATH
        )

        // Find recordings in Movies/NovexRecorder or containing 'Novex'
        val selection = "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ? OR ${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%NovexRecorder%", "NOVEX_%")
        val sortOrder = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"

        try {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val widthCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val pathCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.RELATIVE_PATH)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    val name = cursor.getString(nameCol) ?: "Recording-$id.mp4"
                    val duration = cursor.getLong(durCol)
                    val size = cursor.getLong(sizeCol)
                    val dateModified = cursor.getLong(dateCol) * 1000L
                    var width = cursor.getInt(widthCol)
                    var height = cursor.getInt(heightCol)
                    val mime = cursor.getString(mimeCol) ?: "video/mp4"
                    val relPath = cursor.getString(pathCol) ?: "Movies/NovexRecorder"

                    var calculatedBitrate = 0L
                    if (duration > 0 && size > 0) {
                        calculatedBitrate = (size * 8L) / (duration / 1000L)
                    }

                    // Fallback to retriever if dimensions missing
                    if (width == 0 || height == 0) {
                        try {
                            MediaMetadataRetriever().use { retriever ->
                                retriever.setDataSource(context, contentUri)
                                val wStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                                val hStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                                width = wStr?.toIntOrNull() ?: 1920
                                height = hStr?.toIntOrNull() ?: 1080
                            }
                        } catch (_: Exception) {
                            width = 1920
                            height = 1080
                        }
                    }

                    list.add(
                        RecordingItem(
                            id = id,
                            title = name,
                            uri = contentUri,
                            path = relPath,
                            durationMs = duration,
                            sizeBytes = size,
                            dateModifiedMs = dateModified,
                            width = width,
                            height = height,
                            bitrateBps = calculatedBitrate,
                            mimeType = mime
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        list
    }

    suspend fun deleteRecording(item: RecordingItem): Boolean = withContext(Dispatchers.IO) {
        try {
            val rows = context.contentResolver.delete(item.uri, null, null)
            rows > 0
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun createShareIntent(item: RecordingItem): Intent {
        return Intent(Intent.ACTION_SEND).apply {
            type = item.mimeType
            putExtra(Intent.EXTRA_STREAM, item.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun getStorageMetrics(): StorageMetrics {
        return try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val availableBytes = stat.availableBlocksLong * stat.blockSizeLong
            val totalBytes = stat.blockCountLong * stat.blockSizeLong
            val usedBytes = totalBytes - availableBytes
            StorageMetrics(
                totalBytes = totalBytes,
                usedBytes = usedBytes,
                freeBytes = availableBytes
            )
        } catch (_: Exception) {
            StorageMetrics(
                totalBytes = 128L * 1024 * 1024 * 1024,
                usedBytes = 40L * 1024 * 1024 * 1024,
                freeBytes = 88L * 1024 * 1024 * 1024
            )
        }
    }
}

data class StorageMetrics(
    val totalBytes: Long,
    val usedBytes: Long,
    val freeBytes: Long
) {
    val freeGigabytes: Double get() = freeBytes / (1024.0 * 1024.0 * 1024.0)
    val totalGigabytes: Double get() = totalBytes / (1024.0 * 1024.0 * 1024.0)
    val percentUsed: Int get() = if (totalBytes > 0) ((usedBytes.toDouble() / totalBytes) * 100).toInt() else 0
}
