package com.novex.recorder.data

import android.content.Context
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager

enum class VideoCodec(val mime: String, val label: String) {
    AVC(MediaFormat.MIMETYPE_VIDEO_AVC, "H.264"),
    HEVC(MediaFormat.MIMETYPE_VIDEO_HEVC, "HEVC")
}

/** One concrete attempt: this exact size/fps/codec. */
data class CapturePlan(
    val width: Int,
    val height: Int,
    val fps: Int,
    val codec: VideoCodec,
    val encoderName: String?,
    val upscaled: Boolean,
    val bitrateBps: Int
) {
    val label: String get() = "${width}x$height @ $fps fps • ${codec.label}"
}

data class MatrixCell(val avc: Boolean, val hevc: Boolean)
data class MatrixRow(val resolution: CaptureResolution, val width: Int, val height: Int, val cells: Map<Int, MatrixCell>)

data class EncoderCapabilityReport(
    val deviceModel: String,
    val isNordCe2Lite: Boolean,
    val avcEncoder: String,
    val avcHardware: Boolean,
    val hevcEncoder: String,
    val hevcHardware: Boolean,
    val avcMaxWidth: Int,
    val avcMaxHeight: Int,
    val avcMaxFps: Int,
    val avcBitrateMaxMbps: Int,
    val hevcMaxWidth: Int,
    val hevcMaxHeight: Int,
    val hevcMaxFps: Int,
    val screenWidth: Int,
    val screenHeight: Int
)

object CodecDetector {

    val FPS_OPTIONS = listOf(30, 60, 90, 120)

    fun screenSize(context: Context): Pair<Int, Int> {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        return m.widthPixels to m.heightPixels
    }

    private val encoderCache = HashMap<VideoCodec, MediaCodecInfo?>()

    @Synchronized
    fun pickEncoder(codec: VideoCodec): MediaCodecInfo? =
        if (encoderCache.containsKey(codec)) encoderCache[codec]
        else findEncoder(codec).also { encoderCache[codec] = it }

    private fun findEncoder(codec: VideoCodec): MediaCodecInfo? {
        val infos = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .filter { it.isEncoder && it.supportedTypes.any { t -> t.equals(codec.mime, true) } }
        return infos.firstOrNull { it.isHardwareAccelerated && !it.isSoftwareOnly } ?: infos.firstOrNull()
    }

    private fun videoCaps(codec: VideoCodec): MediaCodecInfo.VideoCapabilities? = try {
        pickEncoder(codec)?.getCapabilitiesForType(codec.mime)?.videoCapabilities
    } catch (_: Exception) { null }

    /** Aspect-matched size (so the video fills the frame, no zoomed-out bars) that the encoder supports. */
    fun sizeFor(
        shortSide: Int, landscape: Boolean, sw: Int, sh: Int, caps: MediaCodecInfo.VideoCapabilities?
    ): Pair<Int, Int> {
        val aspect = maxOf(sw, sh).toDouble() / minOf(sw, sh).coerceAtLeast(1)
        var s = shortSide.toDouble()
        var l = s * aspect
        if (caps != null) {
            val maxLong = (if (landscape) caps.supportedWidths.upper else caps.supportedHeights.upper).toDouble()
            val maxShort = (if (landscape) caps.supportedHeights.upper else caps.supportedWidths.upper).toDouble()
            if (l > maxLong) { l = maxLong; s = l / aspect }
            if (s > maxShort) { s = maxShort; l = s * aspect }
        }
        val wA = caps?.widthAlignment ?: 2
        val hA = caps?.heightAlignment ?: 2
        var w = if (landscape) l else s
        var h = if (landscape) s else l
        w = (w.toInt() / wA * wA).toDouble()
        h = (h.toInt() / hA * hA).toDouble()
        return w.toInt() to h.toInt()
    }

    fun autoBitrateBps(w: Int, h: Int, fps: Int, codec: VideoCodec, caps: MediaCodecInfo.VideoCapabilities?): Int {
        val bpp = if (codec == VideoCodec.HEVC) 0.085 else 0.12
        var bps = (w.toLong() * h * fps * bpp).toLong().coerceIn(6_000_000L, 120_000_000L)
        caps?.let { bps = bps.coerceIn(it.bitrateRange.lower.toLong(), it.bitrateRange.upper.toLong()) }
        return bps.toInt()
    }

    private fun codecOrder(pref: CodecPref) = when (pref) {
        CodecPref.AUTO -> listOf(VideoCodec.AVC, VideoCodec.HEVC)
        CodecPref.H264 -> listOf(VideoCodec.AVC)
        CodecPref.HEVC -> listOf(VideoCodec.HEVC, VideoCodec.AVC)
    }

    /**
     * Ordered list of attempts. First = exactly what the user asked for (if the encoder reports it);
     * then same resolution at lower FPS, then lower resolutions. Never caps below what the phone supports.
     */
    fun buildLadder(cfg: RecordingConfig, sw: Int, sh: Int): List<CapturePlan> {
        val plans = ArrayList<CapturePlan>()
        val nativeShort = minOf(sw, sh)
        val tiers = CaptureResolution.values().map { it.shortSide }.sortedDescending().filter { it <= cfg.resolution.shortSide }
        val fpsList = FPS_OPTIONS.sortedDescending().filter { it <= cfg.frameRate }
        for (tier in tiers) for (fps in fpsList) for (codec in codecOrder(cfg.codecPref)) {
            val info = pickEncoder(codec) ?: continue
            val caps = try { info.getCapabilitiesForType(codec.mime).videoCapabilities } catch (_: Exception) { continue }
            val (w, h) = sizeFor(tier, cfg.landscape, sw, sh, caps)
            if (w <= 0 || h <= 0 || !caps.isSizeSupported(w, h)) continue
            if (!caps.areSizeAndRateSupported(w, h, fps.toDouble())) continue
            val br = if (cfg.bitrateAuto) autoBitrateBps(w, h, fps, codec, caps)
            else (cfg.videoBitrateMbps * 1_000_000L).coerceIn(caps.bitrateRange.lower.toLong(), caps.bitrateRange.upper.toLong()).toInt()
            plans += CapturePlan(w, h, fps, codec, info.name, tier > nativeShort, br)
        }
        if (plans.isEmpty()) {
            val (w, h) = if (cfg.landscape) 1280 to 720 else 720 to 1280
            plans += CapturePlan(w, h, 30, VideoCodec.AVC, null, false, 8_000_000)
        }
        return plans
    }

    /** What the Engine screen shows for a (resolution, fps) pick. */
    fun statusFor(cfg: RecordingConfig, res: CaptureResolution, fps: Int, sw: Int, sh: Int): String {
        val probe = cfg.copy(resolution = res, frameRate = fps)
        val first = buildLadder(probe, sw, sh).firstOrNull() ?: return "FALLBACK"
        val exact = first.encoderName != null && first.fps == fps &&
                minOf(first.width, first.height) >= (res.shortSide * 0.8).toInt()
        return when {
            !exact -> "FALLBACK"
            first.upscaled -> "UPSCALED"
            else -> "NATIVE"
        }
    }

    fun matrix(landscape: Boolean, sw: Int, sh: Int): List<MatrixRow> {
        val avc = videoCaps(VideoCodec.AVC)
        val hevc = videoCaps(VideoCodec.HEVC)
        return CaptureResolution.values().map { r ->
            val (w, h) = sizeFor(r.shortSide, landscape, sw, sh, avc ?: hevc)
            val cells = FPS_OPTIONS.associateWith { f ->
                val (wa, ha) = sizeFor(r.shortSide, landscape, sw, sh, avc)
                val (wh, hh) = sizeFor(r.shortSide, landscape, sw, sh, hevc)
                MatrixCell(
                    avc = avc != null && avc.isSizeSupported(wa, ha) && avc.areSizeAndRateSupported(wa, ha, f.toDouble()),
                    hevc = hevc != null && hevc.isSizeSupported(wh, hh) && hevc.areSizeAndRateSupported(wh, hh, f.toDouble())
                )
            }
            MatrixRow(r, w, h, cells)
        }
    }

    fun inspectDeviceEncoders(context: Context): EncoderCapabilityReport {
        val avcInfo = pickEncoder(VideoCodec.AVC)
        val hevcInfo = pickEncoder(VideoCodec.HEVC)
        val avc = videoCaps(VideoCodec.AVC)
        val hevc = videoCaps(VideoCodec.HEVC)
        val (sw, sh) = screenSize(context)
        val model = "${Build.MANUFACTURER} ${Build.MODEL}"
        val nord = Build.MODEL.contains("CPH2381", true) || Build.MODEL.contains("CPH2409", true) ||
                Build.MODEL.contains("Nord CE 2 Lite", true)
        return EncoderCapabilityReport(
            deviceModel = model,
            isNordCe2Lite = nord,
            avcEncoder = avcInfo?.name ?: "none",
            avcHardware = avcInfo?.isHardwareAccelerated ?: false,
            hevcEncoder = hevcInfo?.name ?: "none",
            hevcHardware = hevcInfo?.isHardwareAccelerated ?: false,
            avcMaxWidth = avc?.supportedWidths?.upper ?: 0,
            avcMaxHeight = avc?.supportedHeights?.upper ?: 0,
            avcMaxFps = avc?.supportedFrameRates?.upper ?: 0,
            avcBitrateMaxMbps = (avc?.bitrateRange?.upper ?: 0) / 1_000_000,
            hevcMaxWidth = hevc?.supportedWidths?.upper ?: 0,
            hevcMaxHeight = hevc?.supportedHeights?.upper ?: 0,
            hevcMaxFps = hevc?.supportedFrameRates?.upper ?: 0,
            screenWidth = sw,
            screenHeight = sh
        )
    }

    fun estimateMbPerMinute(videoMbps: Int, audioKbps: Int): Int =
        (((videoMbps * 1_000_000L) + audioKbps * 1_000L) / 8.0 * 60 / (1024 * 1024)).toInt()
}
