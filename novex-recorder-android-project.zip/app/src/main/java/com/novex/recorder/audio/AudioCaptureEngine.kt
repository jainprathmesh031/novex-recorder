package com.novex.recorder.audio

import android.annotation.SuppressLint
import android.media.*
import android.media.projection.MediaProjection
import android.util.Log
import com.novex.recorder.encoder.MuxerManager
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Captures phone sound (AudioPlaybackCapture) and microphone independently.
 *  - separate tracks: one AAC track per source (pro editing)
 *  - mixed: both sources blended into ONE AAC track (plays everywhere, e.g. Discord / WhatsApp)
 * Each source can be muted/unmuted live; muting keeps the timeline continuous (writes silence).
 */
class AudioCaptureEngine(
    private val sampleRate: Int,
    private val audioBitrateBps: Int,
    private val captureInternal: Boolean,
    private val captureMic: Boolean,
    private val mixed: Boolean,
    private val mediaProjection: MediaProjection?,
    private val muxerManager: MuxerManager
) {
    companion object {
        private const val TAG = "NovexAudioEngine"
        private const val MIME_AAC = MediaFormat.MIMETYPE_AUDIO_AAC
        private const val CHUNK = 4096 // stereo 16-bit bytes (~21 ms @ 48 kHz)

        /** How many audio tracks the muxer should expect for a config. */
        fun expectedTracks(internal: Boolean, mic: Boolean, mixed: Boolean): Int {
            val sources = (if (internal) 1 else 0) + (if (mic) 1 else 0)
            return if (mixed) minOf(sources, 1) else sources
        }
    }

    val internalMuted = AtomicBoolean(false)
    val micMuted = AtomicBoolean(false)

    private class Source(val name: String, val record: AudioRecord, val mono: Boolean, val muted: AtomicBoolean)

    private val isRunning = AtomicBoolean(false)
    private val isPaused = AtomicBoolean(false)
    @Volatile private var generation = 0
    @Volatile private var startNs = 0L
    @Volatile private var pauseOffsetUs = 0L
    private var pauseStartUs = 0L
    private val workers = ArrayList<StreamEncoder>()

    private fun nowUs() = System.nanoTime() / 1000L

    @SuppressLint("MissingPermission")
    fun start(sessionStartNs: Long) {
        if (isRunning.getAndSet(true)) return
        startNs = sessionStartNs
        val sources = ArrayList<Source>()

        if (captureInternal && mediaProjection != null) {
            try {
                val cfg = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()
                val rec = AudioRecord.Builder()
                    .setAudioPlaybackCaptureConfig(cfg)
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferFor(AudioFormat.CHANNEL_IN_STEREO))
                    .build()
                if (rec.state == AudioRecord.STATE_INITIALIZED) {
                    sources += Source("InternalAudio", rec, false, internalMuted)
                } else rec.release()
            } catch (e: Exception) {
                Log.e(TAG, "Internal audio capture unavailable", e)
            }
        }

        if (captureMic) {
            for (mono in listOf(false, true)) {
                try {
                    val mask = if (mono) AudioFormat.CHANNEL_IN_MONO else AudioFormat.CHANNEL_IN_STEREO
                    val rec = AudioRecord(
                        MediaRecorder.AudioSource.MIC, sampleRate, mask,
                        AudioFormat.ENCODING_PCM_16BIT, bufferFor(mask)
                    )
                    if (rec.state == AudioRecord.STATE_INITIALIZED) {
                        sources += Source("MicAudio", rec, mono, micMuted)
                        break
                    } else rec.release()
                } catch (e: Exception) {
                    Log.e(TAG, "Microphone init failed (mono=$mono)", e)
                }
            }
        }

        val groups: List<List<Source>> = when {
            sources.isEmpty() -> emptyList()
            mixed -> listOf(sources.sortedBy { if (it.name == "MicAudio") 0 else 1 }) // mic = steady clock master
            else -> sources.map { listOf(it) }
        }

        val expected = expectedTracks(captureInternal, captureMic, mixed)
        for (group in groups) {
            val worker = StreamEncoder(group)
            if (worker.start()) workers += worker
        }
        // Tell the muxer about tracks that will never arrive so it still starts
        val missing = (expected - workers.size).coerceAtLeast(0)
        repeat(missing) { muxerManager.cancelExpectedTrack() }
        Log.i(TAG, "Audio started: ${workers.size}/$expected tracks")
    }

    private fun bufferFor(mask: Int): Int {
        val min = AudioRecord.getMinBufferSize(sampleRate, mask, AudioFormat.ENCODING_PCM_16BIT)
        return (min * 4).coerceAtLeast(CHUNK * 4)
    }

    fun pause() {
        if (isPaused.compareAndSet(false, true)) pauseStartUs = nowUs()
    }

    fun resume() {
        if (isPaused.get()) {
            pauseOffsetUs += nowUs() - pauseStartUs
            generation++
            isPaused.set(false)
        }
    }

    fun stop() {
        if (!isRunning.getAndSet(false)) return
        workers.forEach { it.stop() }
        workers.clear()
    }

    private inner class StreamEncoder(private val sources: List<Source>) {
        private var codec: MediaCodec? = null
        private var trackIndex = -1
        private val alive = AtomicBoolean(false)
        private var feedThread: Thread? = null
        private var drainThread: Thread? = null

        fun start(): Boolean {
            return try {
                val format = MediaFormat.createAudioFormat(MIME_AAC, sampleRate, 2).apply {
                    setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    setInteger(MediaFormat.KEY_BIT_RATE, audioBitrateBps)
                    setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, CHUNK * 2)
                }
                codec = MediaCodec.createEncoderByType(MIME_AAC).apply {
                    configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    start()
                }
                alive.set(true)
                sources.forEach { it.record.startRecording() }
                val label = sources.joinToString("+") { it.name }
                feedThread = Thread({ feedLoop() }, "Novex-$label-pcm").apply { start() }
                drainThread = Thread({ drainLoop() }, "Novex-$label-aac").apply { start() }
                true
            } catch (e: Exception) {
                Log.e(TAG, "Audio stream failed to start", e)
                alive.set(false)
                sources.forEach { try { it.record.release() } catch (_: Exception) {} }
                try { codec?.release() } catch (_: Exception) {}
                codec = null
                false
            }
        }

        /** Reads up to maxStereoBytes of stereo PCM; blocking only for the master source. */
        private fun readStereo(s: Source, out: ByteArray, maxStereoBytes: Int, blocking: Boolean): Int {
            val mode = if (blocking) AudioRecord.READ_BLOCKING else AudioRecord.READ_NON_BLOCKING
            if (!s.mono) {
                val n = s.record.read(out, 0, maxStereoBytes, mode)
                return if (n > 0) n and 3.inv() else n
            }
            val tmp = ByteArray(maxStereoBytes / 2)
            val n = s.record.read(tmp, 0, tmp.size, mode)
            if (n <= 0) return n
            val frames = n / 2
            for (i in 0 until frames) {
                out[i * 4] = tmp[i * 2]; out[i * 4 + 1] = tmp[i * 2 + 1]
                out[i * 4 + 2] = tmp[i * 2]; out[i * 4 + 3] = tmp[i * 2 + 1]
            }
            return frames * 4
        }

        private fun feedLoop() {
            val c = codec ?: return
            val buf = ByteArray(CHUNK)
            val other = ByteArray(CHUNK)
            var seenGen = generation
            var anchorUs = -1L
            var frames = 0L
            var lastPts = -1L
            try {
                while (alive.get()) {
                    if (isPaused.get()) { Thread.sleep(10); continue }
                    if (seenGen != generation) { seenGen = generation; anchorUs = -1L; frames = 0L }

                    val n = readStereo(sources[0], buf, CHUNK, true)
                    if (n < 0) break
                    if (n == 0) { Thread.sleep(2); continue }
                    if (sources[0].muted.get()) java.util.Arrays.fill(buf, 0, n, 0)

                    for (k in 1 until sources.size) {
                        val s = sources[k]
                        val m = readStereo(s, other, n, false)
                        if (m > 0 && !s.muted.get()) mixInto(buf, other, m)
                    }

                    val chunkUs = n / 4L * 1_000_000L / sampleRate
                    if (anchorUs < 0) {
                        anchorUs = ((System.nanoTime() - startNs) / 1000L - pauseOffsetUs - chunkUs).coerceAtLeast(0L)
                    }
                    var pts = anchorUs + frames * 1_000_000L / sampleRate
                    if (pts <= lastPts) pts = lastPts + 1
                    lastPts = pts
                    frames += n / 4

                    val idx = c.dequeueInputBuffer(20_000L)
                    if (idx >= 0) {
                        val ib = c.getInputBuffer(idx) ?: continue
                        ib.clear()
                        ib.put(buf, 0, n)
                        c.queueInputBuffer(idx, 0, n, pts, 0)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Feed loop error", e)
            }
        }

        private fun mixInto(dst: ByteArray, src: ByteArray, bytes: Int) {
            var i = 0
            while (i + 1 < bytes) {
                val a = (dst[i].toInt() and 0xFF) or (dst[i + 1].toInt() shl 8)
                val b = (src[i].toInt() and 0xFF) or (src[i + 1].toInt() shl 8)
                val sum = (a + b).coerceIn(-32768, 32767)
                dst[i] = (sum and 0xFF).toByte()
                dst[i + 1] = ((sum shr 8) and 0xFF).toByte()
                i += 2
            }
        }

        private fun drainLoop() {
            val c = codec ?: return
            val info = MediaCodec.BufferInfo()
            try {
                while (true) {
                    val idx = c.dequeueOutputBuffer(info, 10_000L)
                    when {
                        idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED ->
                            trackIndex = muxerManager.registerTrack(c.outputFormat)
                        idx >= 0 -> {
                            val data = c.getOutputBuffer(idx)
                            if (data != null && trackIndex >= 0 && !isPaused.get() &&
                                (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                            ) {
                                muxerManager.writeSampleData(trackIndex, data, info)
                            }
                            c.releaseOutputBuffer(idx, false)
                            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                        }
                        idx == MediaCodec.INFO_TRY_AGAIN_LATER && !alive.get() -> break
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Drain loop error", e)
            }
        }

        fun stop() {
            alive.set(false)
            try {
                sources.forEach { try { it.record.stop() } catch (_: Exception) {} }
                feedThread?.join(500)
                drainThread?.join(800)
            } catch (_: Exception) {}
            sources.forEach { try { it.record.release() } catch (_: Exception) {} }
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            codec = null
        }
    }
}
