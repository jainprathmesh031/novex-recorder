package com.novex.recorder

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class NovexApplication : Application() {

    companion object {
        const val CHANNEL_RECORDING_ID = "novex_recording_service_channel"
        const val CHANNEL_ALERT_ID = "novex_alerts_channel"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            // High priority channel for active foreground recording controls
            val recordChannel = NotificationChannel(
                CHANNEL_RECORDING_ID,
                getString(R.string.channel_recording_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.channel_recording_desc)
                setShowBadge(false)
                setSound(null, null)
                enableVibration(false)
            }

            // Alert channel for completion and critical notices
            val alertChannel = NotificationChannel(
                CHANNEL_ALERT_ID,
                "NØVEX Alerts & Status",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Recording saved and encoder status notifications"
                setShowBadge(true)
            }

            notificationManager.createNotificationChannel(recordChannel)
            notificationManager.createNotificationChannel(alertChannel)
        }
    }
}
