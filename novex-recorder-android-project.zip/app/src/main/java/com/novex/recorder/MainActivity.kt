package com.novex.recorder

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.novex.recorder.data.*
import com.novex.recorder.service.ScreenRecordService
import com.novex.recorder.ui.components.novexBackdrop
import com.novex.recorder.ui.screens.*
import com.novex.recorder.ui.theme.Novex
import com.novex.recorder.ui.theme.NovexPalettes
import com.novex.recorder.ui.theme.NovexRecorderTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    companion object {
        const val INSTAGRAM_URL = "https://www.instagram.com/inside.novex?cplk=eW4zeGNsMzZkcDBm"
    }

    private lateinit var prefs: RecordingPreferences
    private lateinit var repo: RecordingRepository
    private var config by mutableStateOf(RecordingConfig())
    private var report by mutableStateOf<EncoderCapabilityReport?>(null)
    private var recordings by mutableStateOf<List<RecordingItem>>(emptyList())
    private var hasOverlay by mutableStateOf(false)

    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ScreenRecordService::class.java).apply {
                action = ScreenRecordService.ACTION_START
                putExtra(ScreenRecordService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenRecordService.EXTRA_RESULT_DATA, data)
            }
            ContextCompat.startForegroundService(this, intent)
        } else {
            Toast.makeText(this, "Screen capture permission declined", Toast.LENGTH_SHORT).show()
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants[Manifest.permission.RECORD_AUDIO] == false) {
            Toast.makeText(this, "Microphone permission is needed for mic and phone-sound capture", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = RecordingPreferences(this)
        repo = RecordingRepository(this)
        config = prefs.loadConfig()
        report = CodecDetector.inspectDeviceEncoders(this)
        requestPermissions()
        refreshRecordings()

        setContent {
            val palette = NovexPalettes.byId(config.themeId)
            NovexRecorderTheme(palette) {
                val state by ScreenRecordService.recordingState.collectAsState()
                val elapsed by ScreenRecordService.elapsedSeconds.collectAsState()
                val activePlan by ScreenRecordService.activePlan.collectAsState()
                val micMuted by ScreenRecordService.micMuted.collectAsState()
                val internalMuted by ScreenRecordService.internalMuted.collectAsState()
                var tab by remember { mutableIntStateOf(0) }
                var inspector by remember { mutableStateOf(false) }

                BackHandler(enabled = inspector) { inspector = false }

                Column(Modifier.fillMaxSize().novexBackdrop().statusBarsPadding()) {
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        if (inspector) {
                            InspectorScreen(report!!, config.landscape) { inspector = false }
                        } else when (tab) {
                            0 -> DashboardScreen(
                                config = config, report = report!!, state = state, elapsedSeconds = elapsed,
                                activePlan = activePlan, micMuted = micMuted, internalMuted = internalMuted,
                                hasOverlayPermission = hasOverlay,
                                onStart = { launchCapture() },
                                onPause = { ScreenRecordService.control(ScreenRecordService.ACTION_PAUSE) },
                                onResume = { ScreenRecordService.control(ScreenRecordService.ACTION_RESUME) },
                                onStop = {
                                    ScreenRecordService.control(ScreenRecordService.ACTION_STOP)
                                    lifecycleScope.launch { kotlinx.coroutines.delay(1500); refreshRecordings() }
                                },
                                onToggleMic = {
                                    if (isLive(state)) ScreenRecordService.control(ScreenRecordService.ACTION_TOGGLE_MIC)
                                    else update(config.copy(captureMicAudio = !config.captureMicAudio))
                                },
                                onToggleInternal = {
                                    if (isLive(state)) ScreenRecordService.control(ScreenRecordService.ACTION_TOGGLE_INTERNAL)
                                    else update(config.copy(captureInternalAudio = !config.captureInternalAudio))
                                },
                                onGrantOverlay = { requestOverlay() },
                                onOpenInspector = { inspector = true },
                                onOpenInstagram = { openInstagram() }
                            )
                            1 -> SettingsScreen(config, { update(it) }, { inspector = true }, { openInstagram() })
                            2 -> LibraryScreen(
                                recordings = recordings,
                                onPlay = { play(it) },
                                onShare = { startActivity(Intent.createChooser(repo.createShareIntent(it), "Share capture")) },
                                onDelete = { item -> lifecycleScope.launch { repo.deleteRecording(item); refreshRecordings() } }
                            )
                            else -> ThemeScreen(config.themeId) { update(config.copy(themeId = it)) }
                        }
                    }
                    NavBar(tab, inspector) { tab = it; inspector = false; if (it == 2) refreshRecordings() }
                }
            }
        }
    }

    private fun isLive(s: ScreenRecordService.RecordingState) =
        s == ScreenRecordService.RecordingState.RECORDING || s == ScreenRecordService.RecordingState.PAUSED

    private fun update(c: RecordingConfig) {
        config = c
        prefs.saveConfig(c)
    }

    @Composable
    private fun NavBar(selected: Int, inInspector: Boolean, onSelect: (Int) -> Unit) {
        val c = Novex.c
        val items = listOf<Pair<String, ImageVector>>(
            "RECORD" to Icons.Rounded.FiberManualRecord,
            "ENGINE" to Icons.Rounded.Tune,
            "VAULT" to Icons.Rounded.VideoLibrary,
            "THEME" to Icons.Rounded.Palette
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(c.surface)
                .padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items.forEachIndexed { i, (label, icon) ->
                val on = i == selected && !inInspector
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (on) Brush.horizontalGradient(listOf(c.accent, c.accent2)) else Brush.horizontalGradient(listOf(c.surface, c.surface)))
                        .clickable { onSelect(i) }
                        .padding(vertical = 9.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(icon, label, tint = if (on) androidx.compose.ui.graphics.Color.White else c.textDim, modifier = Modifier.size(22.dp))
                    Text(label, color = if (on) androidx.compose.ui.graphics.Color.White else c.textDim,
                        fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        hasOverlay = Settings.canDrawOverlays(this)
        refreshRecordings()
    }

    private fun requestPermissions() {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) permissionLauncher.launch(need.toTypedArray())
    }

    private fun launchCapture() {
        val pm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(pm.createScreenCaptureIntent())
    }

    private fun requestOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    private fun play(item: RecordingItem) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(item.uri, "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        } catch (_: Exception) {
            Toast.makeText(this, "No video player found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openInstagram() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(INSTAGRAM_URL)))
        } catch (_: Exception) {
            Toast.makeText(this, "Could not open Instagram", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshRecordings() {
        lifecycleScope.launch { recordings = repo.getRecordings() }
    }
}
