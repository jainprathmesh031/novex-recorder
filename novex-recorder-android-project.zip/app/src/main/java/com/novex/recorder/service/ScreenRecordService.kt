package com.novex.recorder.service

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.novex.recorder.MainActivity
import com.novex.recorder.NovexApplication
import com.novex.recorder.R
import com.novex.recorder.audio.AudioCaptureEngine
import com.novex.recorder.data.AudioMuxingMode
import com.novex.recorder.data.CapturePlan
import com.novex.recorder.data.CodecDetector
import com.novex.recorder.data.RecordingPreferences
import com.novex.recorder.encoder.MuxerManager
import com.novex.recorder.encoder.VideoEncoderCore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

class ScreenRecordService : Service() {

    enum class RecordingState { IDLE, STARTING, RECORDING, PAUSED, STOPPING }

    companion object {
        private const val TAG = "NovexRecordService"
        private const val NOTIFICATION_ID = 8801

        const val ACTION_START = "com.novex.recorder.ACTION_START"
        const val ACTION_STOP = "com.novex.recorder.ACTION_STOP"
        const val ACTION_PAUSE = "com.novex.recorder.ACTION_PAUSE"
        const val ACTION_RESUME = "com.novex.recorder.ACTION_RESUME"
        const val ACTION_TOGGLE_MIC = "com.novex.recorder.ACTION_TOGGLE_MIC"
        const val ACTION_TOGGLE_INTERNAL = "com.novex.recorder.ACTION_TOGGLE_INTERNAL"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        /** Set when Android rejects a screen-capture permission token, so the app asks again next time. */
        @Volatile var captureTokenRejected = false
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private val _state = MutableStateFlow(RecordingState.IDLE)
        val recordingState: StateFlow<RecordingState> = _state.asStateFlow()

        private val _elapsed = MutableStateFlow(0L)
        val elapsedSeconds: StateFlow<Long> = _elapsed.asStateFlow()

        private val _micMuted = MutableStateFlow(false)
        val micMuted: StateFlow<Boolean> = _micMuted.asStateFlow()

        private val _internalMuted = MutableStateFlow(false)
        val internalMuted: StateFlow<Boolean> = _internalMuted.asStateFlow()

        private val _activePlan = MutableStateFlow<String?>(null)
        /** e.g. "3840x1728 @ 30 fps • HEVC" — what is REALLY being recorded. */
        val activePlan: StateFlow<String?> = _activePlan.asStateFlow()

        @Volatile private var instance: ScreenRecordService? = null

        /** Direct, reliable control from the overlay / UI (no intent round-trip). */
        fun control(action: String) {
            val svc = instance ?: return
            Handler(Looper.getMainLooper()).post { svc.handle(action) }
        }
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var videoEncoder: VideoEncoderCore? = null
    private var audioEngine: AudioCaptureEngine? = null
    private var muxerManager: MuxerManager? = null
    private var outputUri: Uri? = null
    private var parcelFd: ParcelFileDescriptor? = null
    private var stopRequested = false

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var timerJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_START) {
            val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            @Suppress("DEPRECATION")
            val data = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
            if (data != null) startSession(code, data) else stopSelf()
        } else if (action != null) {
            handle(action)
        }
        return START_NOT_STICKY
    }

    private fun handle(action: String) {
        when (action) {
            ACTION_STOP -> stopSession()
            ACTION_PAUSE -> pauseSession()
            ACTION_RESUME -> resumeSession()
            ACTION_TOGGLE_MIC -> toggleMic()
            ACTION_TOGGLE_INTERNAL -> toggleInternal()
        }
    }

    // ───────────────────────── start ─────────────────────────

    private fun startSession(resultCode: Int, resultData: Intent) {
        if (_state.value != RecordingState.IDLE) return
        _state.value = RecordingState.STARTING
        stopRequested = false
        _activePlan.value = null

        val config = RecordingPreferences(this).loadConfig()
        val permitted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        val wantInternal = config.captureInternalAudio && permitted
        val wantMic = config.captureMicAudio && permitted

        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (wantMic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        try {
            startForeground(NOTIFICATION_ID, buildNotification("Preparing engine…", false), type)
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
            toast("Could not start foreground service: ${e.message}")
            _state.value = RecordingState.IDLE
            stopSelf()
            return
        }

        // MediaProjection must be created on this thread, right after startForeground
        val projection = try {
            val pm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            pm.getMediaProjection(resultCode, resultData)
        } catch (e: Exception) {
            Log.e(TAG, "getMediaProjection failed", e)
            null
        }
        if (projection == null) {
            captureTokenRejected = true
            toast("Screen capture permission expired - tap Start again")
            abortSession()
            return
        }
        mediaProjection = projection
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                Log.w(TAG, "MediaProjection stopped")
                scope.launch { stopSession() }
            }
        }, Handler(Looper.getMainLooper()))

        val (sw, sh) = CodecDetector.screenSize(this)
        val cfg = if (config.orientationAuto) config.copy(landscape = sw > sh) else config
        val density = resources.displayMetrics.densityDpi

        // Heavy work (codec probing / configure / start) off the main thread → no ANR
        scope.launch {
            val ok = withContext(Dispatchers.Default) {
                try {
                    setupPipeline(cfg, wantInternal, wantMic, sw, sh, density)
                } catch (e: Exception) {
                    Log.e(TAG, "Pipeline setup failed", e)
                    withContext(Dispatchers.Main) { toast("Recording failed to start: ${e.message}") }
                    false
                }
            }
            if (!ok) { abortSession(); return@launch }
            if (stopRequested) { stopSession(forceFromStarting = true); return@launch }

            _state.value = RecordingState.RECORDING
            _elapsed.value = 0L
            startTimer()
            if (config.showFloatingOverlay) FloatingOverlayService.startOverlay(this@ScreenRecordService)
            updateNotification("Recording • ${_activePlan.value ?: ""}", false)
        }
    }

    private fun setupPipeline(
        config: com.novex.recorder.data.RecordingConfig,
        wantInternal: Boolean, wantMic: Boolean, sw: Int, sh: Int, density: Int
    ): Boolean {
        val projection = mediaProjection ?: return false
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "NOVEX_${config.resolution.label}_$stamp.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/NovexRecorder")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        outputUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Could not create output file")
        parcelFd = contentResolver.openFileDescriptor(outputUri!!, "rw") ?: error("Could not open output file")

        val mixed = config.audioMuxingMode == AudioMuxingMode.DOWNMIXED_STEREO
        val expected = 1 + AudioCaptureEngine.expectedTracks(wantInternal, wantMic, mixed)
        val muxer = MuxerManager(parcelFd!!.fileDescriptor, expected)
        muxerManager = muxer

        // Try the requested config first, then step down only as far as this phone requires
        val ladder = CodecDetector.buildLadder(config, sw, sh)
        var chosen: CapturePlan? = null
        var chosenSurface: android.view.Surface? = null
        var lastError: Exception? = null
        for (plan in ladder.take(14)) {
            val enc = VideoEncoderCore(plan, muxer)
            try {
                chosenSurface = enc.prepare()
                videoEncoder = enc
                chosen = plan
                break
            } catch (e: Exception) {
                Log.w(TAG, "Plan rejected: ${plan.label}", e)
                lastError = e
                try { enc.stop() } catch (_: Exception) {}
            }
        }
        if (chosen == null || chosenSurface == null) throw IllegalStateException("No encoder mode worked", lastError)

        // Android 14+: a projection may create only ONE VirtualDisplay, so create it once, after the plan is final
        virtualDisplay = projection.createVirtualDisplay(
            "NovexVirtualDisplay", chosen.width, chosen.height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, chosenSurface, null, null
        )
        videoEncoder!!.onFatal = {
            Handler(Looper.getMainLooper()).post {
                toast("Encoder stopped unexpectedly – recording saved")
                stopSession()
            }
        }

        val requestedLabel = "${config.resolution.label} @ ${config.frameRate}"
        val note = if (chosen.upscaled) " (upscaled)" else ""
        _activePlan.value = chosen.label + note
        Log.i(TAG, "Recording ${chosen.label}$note (requested $requestedLabel)")

        _micMuted.value = false
        _internalMuted.value = false
        val audio = AudioCaptureEngine(
            sampleRate = config.audioSampleRateHz,
            audioBitrateBps = config.audioBitrateKbps * 1000,
            captureInternal = wantInternal,
            captureMic = wantMic,
            mixed = mixed,
            mediaProjection = projection,
            muxerManager = muxer
        )
        audioEngine = audio
        videoEncoder!!.start()
        audio.start(videoEncoder!!.startTimeUs() * 1000L)
        return true
    }

    private fun abortSession() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { mediaProjection?.stop() } catch (_: Exception) {}
        try { videoEncoder?.stop() } catch (_: Exception) {}
        try { audioEngine?.stop() } catch (_: Exception) {}
        try { muxerManager?.release() } catch (_: Exception) {}
        try { parcelFd?.close() } catch (_: Exception) {}
        outputUri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) {} }
        virtualDisplay = null; mediaProjection = null; videoEncoder = null
        audioEngine = null; muxerManager = null; parcelFd = null; outputUri = null
        _activePlan.value = null
        _state.value = RecordingState.IDLE
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ───────────────────────── controls ─────────────────────────

    private fun pauseSession() {
        if (_state.value != RecordingState.RECORDING) return
        videoEncoder?.pause()
        audioEngine?.pause()
        _state.value = RecordingState.PAUSED
        timerJob?.cancel()
        updateNotification("Paused", true)
    }

    private fun resumeSession() {
        if (_state.value != RecordingState.PAUSED) return
        videoEncoder?.resume()
        audioEngine?.resume()
        _state.value = RecordingState.RECORDING
        startTimer()
        updateNotification("Recording • ${_activePlan.value ?: ""}", false)
    }

    private fun toggleMic() {
        val e = audioEngine ?: return
        val now = !e.micMuted.get()
        e.micMuted.set(now); _micMuted.value = now
        updateNotification(if (_state.value == RecordingState.PAUSED) "Paused" else "Recording • ${_activePlan.value ?: ""}",
            _state.value == RecordingState.PAUSED)
    }

    private fun toggleInternal() {
        val e = audioEngine ?: return
        val now = !e.internalMuted.get()
        e.internalMuted.set(now); _internalMuted.value = now
    }

    private fun stopSession(forceFromStarting: Boolean = false) {
        val st = _state.value
        if (st == RecordingState.STARTING && !forceFromStarting) { stopRequested = true; return }
        if (st == RecordingState.STOPPING || st == RecordingState.IDLE) return
        _state.value = RecordingState.STOPPING
        timerJob?.cancel()
        FloatingOverlayService.stopOverlay(this)

        scope.launch(Dispatchers.IO) {
            try {
                virtualDisplay?.release(); virtualDisplay = null
                videoEncoder?.stop(); videoEncoder = null
                audioEngine?.stop(); audioEngine = null
                muxerManager?.release(); muxerManager = null
                try { mediaProjection?.stop() } catch (_: Exception) {}
                mediaProjection = null
                parcelFd?.close(); parcelFd = null
                outputUri?.let {
                    contentResolver.update(it, ContentValues().apply {
                        put(MediaStore.Video.Media.IS_PENDING, 0)
                    }, null, null)
                }
                Log.i(TAG, "Recording saved: $outputUri")
            } catch (e: Exception) {
                Log.e(TAG, "Error finalizing recording", e)
            } finally {
                withContext(Dispatchers.Main) {
                    _activePlan.value = null
                    _state.value = RecordingState.IDLE
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    toast("Saved to Movies/NovexRecorder")
                }
            }
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = scope.launch {
            while (_state.value == RecordingState.RECORDING) {
                delay(1000)
                _elapsed.value += 1
                updateNotification("Recording ${fmt(_elapsed.value)}", false)
            }
        }
    }

    // ───────────────────────── notification ─────────────────────────

    private fun pi(code: Int, action: String): PendingIntent = PendingIntent.getService(
        this, code, Intent(this, ScreenRecordService::class.java).apply { this.action = action },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun buildNotification(text: String, paused: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_SINGLE_TOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val micOff = _micMuted.value
        return NotificationCompat.Builder(this, NovexApplication.CHANNEL_RECORDING_ID)
            .setContentTitle("NØVEX Recorder")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_stat_rec)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, if (paused) "Resume" else "Pause", pi(2, if (paused) ACTION_RESUME else ACTION_PAUSE))
            .addAction(0, if (micOff) "Mic ON" else "Mic OFF", pi(3, ACTION_TOGGLE_MIC))
            .addAction(0, "Stop", pi(1, ACTION_STOP))
            .build()
    }

    private fun updateNotification(text: String, paused: Boolean) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_ID, buildNotification(text, paused))
    }

    private fun fmt(sec: Long) = String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)

    private fun toast(msg: String) {
        Handler(Looper.getMainLooper()).post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
        scope.cancel()
    }
}
