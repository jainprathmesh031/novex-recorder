package com.novex.recorder.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novex.recorder.ui.theme.Novex
import com.novex.recorder.ui.theme.NovexPalette
import com.novex.recorder.ui.theme.NovexPalettes

@Composable
fun ThemeScreen(selectedId: String, onSelect: (String) -> Unit) {
    val c = Novex.c
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)
    ) {
        item {
            Text("THEME", color = c.text, fontWeight = FontWeight.Black, fontSize = 30.sp, letterSpacing = 3.sp)
            Text("Pick a palette. The whole app and floating controls follow it.", color = c.textDim, style = MaterialTheme.typography.bodySmall)
        }
        val rows = NovexPalettes.all.chunked(2)
        items(rows.size) { i ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                rows[i].forEach { p ->
                    PaletteCard(p, p.id == selectedId, Modifier.weight(1f)) { onSelect(p.id) }
                }
                if (rows[i].size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun PaletteCard(p: NovexPalette, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(p.bgTop, p.bgBottom)))
            .border(BorderStroke(if (selected) 2.5.dp else 1.dp, if (selected) p.accent else p.border), shape)
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Box(
            Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(14.dp))
                .background(Brush.horizontalGradient(listOf(p.accent, p.accent2))),
            contentAlignment = Alignment.TopEnd
        ) {
            if (selected) {
                Box(Modifier.padding(8.dp).size(24.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Check, null, tint = p.bgBottom, modifier = Modifier.size(16.dp))
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(p.surfaceHigh, p.record, p.text, p.textDim).forEach {
                Box(Modifier.size(16.dp).clip(CircleShape).background(it).border(BorderStroke(1.dp, p.border), CircleShape))
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(p.name.uppercase(), color = p.text, fontWeight = FontWeight.Black, fontSize = 13.sp, letterSpacing = 1.sp)
    }
}
