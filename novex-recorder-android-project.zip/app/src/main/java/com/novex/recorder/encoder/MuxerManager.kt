package com.novex.recorder.encoder

import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import java.io.FileDescriptor
import java.nio.ByteBuffer

/**
 * Thread-safe MediaMuxer wrapper: 1 video track + 0..2 audio tracks.
 * - Samples that arrive before the muxer starts are queued (so the first keyframe is never lost).
 * - If an audio source fails to start, call [cancelExpectedTrack] so the muxer still starts.
 */
class MuxerManager(
    outputFd: FileDescriptor,
    expectedTrackCount: Int
) {
    companion object {
        private const val TAG = "NovexMuxerManager"
        private const val MAX_PENDING_BYTES = 32 * 1024 * 1024
    }

    private class Pending(val track: Int, val data: ByteArray, val info: MediaCodec.BufferInfo)

    private val mediaMuxer = MediaMuxer(outputFd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private val lock = Any()
    private var expectedTracks = expectedTrackCount
    private var registeredTracks = 0
    private var isStarted = false
    private var isClosed = false
    private val pending = ArrayList<Pending>()
    private var pendingBytes = 0

    fun registerTrack(format: MediaFormat): Int = synchronized(lock) {
        check(!isStarted) { "Cannot add track after MediaMuxer has started" }
        val index = mediaMuxer.addTrack(format)
        registeredTracks++
        Log.d(TAG, "Registered track $index ($registeredTracks/$expectedTracks)")
        startIfReady()
        index
    }

    /** An expected track will never arrive (e.g. audio source failed). */
    fun cancelExpectedTrack() = synchronized(lock) {
        if (isStarted || isClosed) return@synchronized
        expectedTracks--
        Log.w(TAG, "Expected track cancelled; now expecting $expectedTracks")
        startIfReady()
    }

    private fun startIfReady() {
        if (!isStarted && expectedTracks > 0 && registeredTracks >= expectedTracks) {
            mediaMuxer.start()
            isStarted = true
            Log.i(TAG, "MediaMuxer started with $registeredTracks tracks")
            for (p in pending) write(p.track, ByteBuffer.wrap(p.data), p.info)
            pending.clear()
            pendingBytes = 0
        }
    }

    fun writeSampleData(trackIndex: Int, byteBuffer: ByteBuffer, bufferInfo: MediaCodec.BufferInfo) {
        synchronized(lock) {
            if (isClosed) return
            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0 || bufferInfo.size <= 0) return
            if (!isStarted) {
                if (pendingBytes + bufferInfo.size > MAX_PENDING_BYTES) return
                val copy = ByteArray(bufferInfo.size)
                byteBuffer.position(bufferInfo.offset)
                byteBuffer.limit(bufferInfo.offset + bufferInfo.size)
                byteBuffer.get(copy)
                val info = MediaCodec.BufferInfo().apply {
                    set(0, copy.size, bufferInfo.presentationTimeUs, bufferInfo.flags)
                }
                pending.add(Pending(trackIndex, copy, info))
                pendingBytes += copy.size
                return
            }
            write(trackIndex, byteBuffer, bufferInfo)
        }
    }

    private fun write(trackIndex: Int, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        try {
            mediaMuxer.writeSampleData(trackIndex, buf, info)
        } catch (e: Exception) {
            Log.e(TAG, "Error writing sample to track $trackIndex", e)
        }
    }

    fun release() {
        synchronized(lock) {
            if (isClosed) return
            isClosed = true
            try {
                if (isStarted) mediaMuxer.stop()
                mediaMuxer.release()
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping/releasing MediaMuxer", e)
            } finally {
                isStarted = false
            }
        }
    }
}
