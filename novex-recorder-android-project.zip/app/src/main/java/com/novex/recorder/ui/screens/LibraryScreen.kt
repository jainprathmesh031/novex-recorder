package com.novex.recorder.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novex.recorder.data.RecordingItem
import com.novex.recorder.ui.components.GlassCard
import com.novex.recorder.ui.theme.Novex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun LibraryScreen(
    recordings: List<RecordingItem>,
    onPlay: (RecordingItem) -> Unit,
    onShare: (RecordingItem) -> Unit,
    onDelete: (RecordingItem) -> Unit
) {
    val c = Novex.c
    var pendingDelete by remember { mutableStateOf<RecordingItem?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)
    ) {
        item {
            Text("VAULT", color = c.text, fontWeight = FontWeight.Black, fontSize = 30.sp, letterSpacing = 3.sp)
            Text("${recordings.size} capture${if (recordings.size == 1) "" else "s"} • Movies/NovexRecorder", color = c.textDim, style = MaterialTheme.typography.bodySmall)
        }
        if (recordings.isEmpty()) {
            item {
                GlassCard {
                    Column(Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.Movie, null, tint = c.accent, modifier = Modifier.size(40.dp))
                        Spacer(Modifier.height(10.dp))
                        Text("No captures yet", color = c.text, fontWeight = FontWeight.Bold)
                        Text("Your recordings will appear here.", color = c.textDim, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        items(recordings, key = { it.id }) { item ->
            GlassCard(padding = 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Thumb(item, Modifier.size(width = 112.dp, height = 68.dp).clip(RoundedCornerShape(12.dp)).clickable { onPlay(item) })
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.title, color = c.text, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(3.dp))
                        Text("${item.durationFormatted} • ${item.sizeFormatted}", color = c.textDim, fontSize = 11.sp)
                        Text("${item.width}x${item.height}", color = c.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    IconButton(onClick = { onPlay(item) }) { Icon(Icons.Rounded.PlayCircle, "Play", tint = c.accent) }
                    IconButton(onClick = { onShare(item) }) { Icon(Icons.Rounded.Share, "Share", tint = c.text) }
                    IconButton(onClick = { pendingDelete = item }) { Icon(Icons.Rounded.Delete, "Delete", tint = c.record) }
                }
            }
        }
    }

    pendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            containerColor = c.surfaceHigh,
            title = { Text("Delete capture?", color = c.text) },
            text = { Text(target.title, color = c.textDim) },
            confirmButton = {
                TextButton(onClick = { onDelete(target); pendingDelete = null }) { Text("DELETE", color = c.record) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("CANCEL", color = c.textDim) } }
        )
    }
}

@Composable
private fun Thumb(item: RecordingItem, modifier: Modifier) {
    val c = Novex.c
    val ctx: Context = LocalContext.current
    val bmp by produceState<Bitmap?>(null, item.id) {
        value = withContext(Dispatchers.IO) {
            try { ctx.contentResolver.loadThumbnail(item.uri, Size(320, 200), null) } catch (_: Exception) { null }
        }
    }
    Box(modifier.background(c.surface), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        else Icon(Icons.Rounded.Movie, null, tint = c.textDim)
    }
}
