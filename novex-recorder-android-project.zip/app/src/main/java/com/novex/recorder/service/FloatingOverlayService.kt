package com.novex.recorder.service

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.novex.recorder.R
import com.novex.recorder.data.RecordingPreferences
import com.novex.recorder.ui.theme.NovexPalettes
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

/**
 * Premium floating control pill.
 *  - Starts collapsed into a tiny handle; tap to expand, auto-collapses after 3 s.
 *  - Stealth mode: collapsed handle is almost transparent so it barely shows in the video.
 *  - Drag anywhere. Buttons: pause/resume, mic on/off, phone-sound on/off, stop.
 */
class FloatingOverlayService : Service() {

    companion object {
        fun startOverlay(context: Context) {
            if (Settings.canDrawOverlays(context)) {
                try { context.startService(Intent(context, FloatingOverlayService::class.java)) } catch (_: Exception) {}
            }
        }

        fun stopOverlay(context: Context) {
            context.stopService(Intent(context, FloatingOverlayService::class.java))
        }
    }

    private class DragFrame(context: Context, val onTap: () -> Unit, val onDrag: (Int, Int) -> Unit) : FrameLayout(context) {
        private val slop = ViewConfiguration.get(context).scaledTouchSlop
        private var downX = 0f
        private var downY = 0f
        private var lastX = 0f
        private var lastY = 0f
        private var dragging = false

        override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; lastX = downX; lastY = downY; dragging = false }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging && (Math.abs(e.rawX - downX) > slop || Math.abs(e.rawY - downY) > slop)) dragging = true
                    if (dragging) return true
                }
            }
            return false
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; lastX = downX; lastY = downY; dragging = false }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging && (Math.abs(e.rawX - downX) > slop || Math.abs(e.rawY - downY) > slop)) dragging = true
                    if (dragging) {
                        onDrag((e.rawX - lastX).toInt(), (e.rawY - lastY).toInt())
                        lastX = e.rawX; lastY = e.rawY
                    }
                }
                MotionEvent.ACTION_UP -> if (!dragging) onTap()
            }
            return true
        }
    }

    private val ui = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var wm: WindowManager? = null
    private var root: DragFrame? = null
    private var params: WindowManager.LayoutParams? = null

    private lateinit var panel: LinearLayout
    private lateinit var handle: View
    private lateinit var timerText: TextView
    private lateinit var pauseBtn: ImageView
    private lateinit var micBtn: ImageView
    private lateinit var sndBtn: ImageView
    private var expanded = false
    private var stealth = true

    private var cText = 0; private var cDim = 0; private var cAccent = 0; private var cAccent2 = 0
    private var cRec = 0; private var cSurface = 0; private var cSurfaceHigh = 0; private var cOk = 0

    private val collapseRunnable = Runnable { setExpanded(false) }
    // After a few seconds the handle fades to its resting opacity (faint in stealth mode, but still findable)
    private val dimRunnable = Runnable {
        if (!expanded && ::handle.isInitialized) handle.animate().alpha(if (stealth) 0.3f else 0.9f).setDuration(400).start()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }

        val cfg = RecordingPreferences(this).loadConfig()
        stealth = cfg.stealthOverlay
        val p = NovexPalettes.byId(cfg.themeId)
        fun Color.i() = this.toArgb()
        cText = p.text.i(); cDim = p.textDim.i(); cAccent = p.accent.i(); cAccent2 = p.accent2.i()
        cRec = p.record.i(); cSurface = p.surface.i(); cSurfaceHigh = p.surfaceHigh.i(); cOk = p.ok.i()

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        root = DragFrame(this, onTap = { if (!expanded) setExpanded(true) }, onDrag = { dx, dy ->
            params?.let { lp -> lp.x += dx; lp.y += dy; wm?.updateViewLayout(root, lp) }
        }).also { r ->
            buildPanel()
            buildHandle()
            r.addView(panel)
            r.addView(handle)
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14); y = dp(120)
        }
        try {
            wm?.addView(root, params)
        } catch (e: Exception) {
            android.util.Log.e("FloatingOverlay", "addView failed", e)
            android.widget.Toast.makeText(this, "Floating controls failed: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        setExpanded(false)
        observe()
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun circle(color: Int, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun buildPanel() {
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(7), dp(8), dp(7))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cSurface, cSurfaceHigh)).apply {
                cornerRadius = dp(30).toFloat()
                setStroke(dp(1), withAlpha(cAccent, 0.75f))
            }
            elevation = dp(10).toFloat()
        }
        val dot = View(this).apply {
            background = circle(cRec)
            layoutParams = LinearLayout.LayoutParams(dp(9), dp(9)).apply { rightMargin = dp(8) }
        }
        timerText = TextView(this).apply {
            text = "00:00"
            setTextColor(cText)
            textSize = 14f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(12) }
        }
        pauseBtn = actionButton(R.drawable.ic_pause, withAlpha(cAccent, 0.22f), cText) {
            val st = ScreenRecordService.recordingState.value
            ScreenRecordService.control(
                if (st == ScreenRecordService.RecordingState.PAUSED) ScreenRecordService.ACTION_RESUME
                else ScreenRecordService.ACTION_PAUSE
            )
            scheduleCollapse()
        }
        micBtn = actionButton(R.drawable.ic_mic, withAlpha(cAccent, 0.22f), cText) {
            ScreenRecordService.control(ScreenRecordService.ACTION_TOGGLE_MIC); scheduleCollapse()
        }
        sndBtn = actionButton(R.drawable.ic_volume, withAlpha(cAccent, 0.22f), cText) {
            ScreenRecordService.control(ScreenRecordService.ACTION_TOGGLE_INTERNAL); scheduleCollapse()
        }
        val stopBtn = actionButton(R.drawable.ic_stop, cRec, 0xFFFFFFFF.toInt()) {
            ScreenRecordService.control(ScreenRecordService.ACTION_STOP)
        }
        stopBtn.layoutParams = LinearLayout.LayoutParams(dp(38), dp(38))
        panel.addView(dot); panel.addView(timerText)
        panel.addView(pauseBtn); panel.addView(micBtn); panel.addView(sndBtn); panel.addView(stopBtn)
    }

    private fun actionButton(icon: Int, bg: Int, tint: Int, onClick: () -> Unit) = ImageView(this).apply {
        setImageResource(icon)
        setColorFilter(tint)
        background = circle(bg)
        setPadding(dp(8), dp(8), dp(8), dp(8))
        layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)).apply { rightMargin = dp(6) }
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun buildHandle() {
        handle = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(cAccent, cAccent2)).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), withAlpha(0xFFFFFFFF.toInt(), 0.85f))
            }
            layoutParams = FrameLayout.LayoutParams(dp(36), dp(36))
        }
    }

    private fun setExpanded(value: Boolean) {
        expanded = value
        panel.visibility = if (value) View.VISIBLE else View.GONE
        handle.visibility = if (value) View.GONE else View.VISIBLE
        handle.animate().cancel()
        handle.alpha = 1f
        ui.removeCallbacks(dimRunnable)
        ui.removeCallbacks(collapseRunnable)
        if (value) scheduleCollapse() else ui.postDelayed(dimRunnable, 5000)
        root?.let { r -> params?.let { lp -> try { wm?.updateViewLayout(r, lp) } catch (_: Exception) {} } }
    }

    private fun scheduleCollapse() {
        ui.removeCallbacks(collapseRunnable)
        ui.postDelayed(collapseRunnable, 3500)
    }

    private fun withAlpha(color: Int, a: Float): Int =
        (color and 0x00FFFFFF) or ((a * 255).toInt().coerceIn(0, 255) shl 24)

    private fun observe() {
        scope.launch {
            ScreenRecordService.elapsedSeconds.collectLatest { sec ->
                timerText.text = String.format(java.util.Locale.US, "%02d:%02d", sec / 60, sec % 60)
            }
        }
        scope.launch {
            ScreenRecordService.recordingState.collectLatest { st ->
                pauseBtn.setImageResource(if (st == ScreenRecordService.RecordingState.PAUSED) R.drawable.ic_play else R.drawable.ic_pause)
                if (st == ScreenRecordService.RecordingState.IDLE) stopSelf()
            }
        }
        scope.launch {
            ScreenRecordService.micMuted.collectLatest { off ->
                micBtn.setImageResource(if (off) R.drawable.ic_mic_off else R.drawable.ic_mic)
                micBtn.setColorFilter(if (off) cRec else cText)
            }
        }
        scope.launch {
            ScreenRecordService.internalMuted.collectLatest { off ->
                sndBtn.setImageResource(if (off) R.drawable.ic_volume_off else R.drawable.ic_volume)
                sndBtn.setColorFilter(if (off) cRec else cText)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacksAndMessages(null)
        scope.cancel()
        root?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        root = null
    }
}
