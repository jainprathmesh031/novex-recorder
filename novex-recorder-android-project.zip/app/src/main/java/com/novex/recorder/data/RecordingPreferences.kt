package com.novex.recorder.data

import android.content.Context

enum class CaptureResolution(val label: String, val tag: String, val shortSide: Int) {
    R720("720p", "HD", 720),
    R1080("1080p", "FHD", 1080),
    R1440("2K", "QHD", 1440),
    R2160("4K", "UHD", 2160)
}

enum class CodecPref(val label: String) {
    AUTO("Auto"), H264("H.264"), HEVC("HEVC")
}

enum class AudioMuxingMode(val label: String, val description: String) {
    SEPARATE_TRACKS(
        "Separate tracks",
        "Phone sound and mic saved as two tracks (pro editing). Most phone players only play track 1."
    ),
    DOWNMIXED_STEREO(
        "Single mixed track",
        "Phone sound + mic blended into one track. Plays everywhere (Discord, WhatsApp, Gallery)."
    )
}

data class RecordingConfig(
    val resolution: CaptureResolution = CaptureResolution.R1080,
    val frameRate: Int = 60,
    val codecPref: CodecPref = CodecPref.AUTO,
    val bitrateAuto: Boolean = true,
    val videoBitrateMbps: Int = 20,
    val landscape: Boolean = true,
    val orientationAuto: Boolean = true,
    val captureInternalAudio: Boolean = true,
    val captureMicAudio: Boolean = true,
    val audioBitrateKbps: Int = 192,
    val audioSampleRateHz: Int = 48000,
    val audioMuxingMode: AudioMuxingMode = AudioMuxingMode.SEPARATE_TRACKS,
    val countdownSeconds: Int = 3,
    val showFloatingOverlay: Boolean = true,
    val stealthOverlay: Boolean = true,
    val themeId: String = "void_violet"
)

class RecordingPreferences(context: Context) {
    private val p = context.getSharedPreferences("novex_recorder_prefs_v2", Context.MODE_PRIVATE)

    private inline fun <reified T : Enum<T>> enumOf(key: String, def: T): T =
        try { enumValueOf<T>(p.getString(key, def.name) ?: def.name) } catch (_: Exception) { def }

    fun loadConfig(): RecordingConfig {
        val d = RecordingConfig()
        return RecordingConfig(
            resolution = enumOf("res", d.resolution),
            frameRate = p.getInt("fps", d.frameRate),
            codecPref = enumOf("codec", d.codecPref),
            bitrateAuto = p.getBoolean("br_auto", d.bitrateAuto),
            videoBitrateMbps = p.getInt("br", d.videoBitrateMbps),
            landscape = p.getBoolean("landscape", d.landscape),
            orientationAuto = p.getBoolean("orient_auto", d.orientationAuto),
            captureInternalAudio = p.getBoolean("a_int", d.captureInternalAudio),
            captureMicAudio = p.getBoolean("a_mic", d.captureMicAudio),
            audioBitrateKbps = p.getInt("a_br", d.audioBitrateKbps),
            audioMuxingMode = enumOf("a_mux", d.audioMuxingMode),
            countdownSeconds = p.getInt("countdown", d.countdownSeconds),
            showFloatingOverlay = p.getBoolean("overlay", d.showFloatingOverlay),
            stealthOverlay = p.getBoolean("stealth", d.stealthOverlay),
            themeId = p.getString("theme", d.themeId) ?: d.themeId
        )
    }

    fun saveConfig(c: RecordingConfig) {
        p.edit()
            .putString("res", c.resolution.name)
            .putInt("fps", c.frameRate)
            .putString("codec", c.codecPref.name)
            .putBoolean("br_auto", c.bitrateAuto)
            .putInt("br", c.videoBitrateMbps)
            .putBoolean("landscape", c.landscape)
            .putBoolean("orient_auto", c.orientationAuto)
            .putBoolean("a_int", c.captureInternalAudio)
            .putBoolean("a_mic", c.captureMicAudio)
            .putInt("a_br", c.audioBitrateKbps)
            .putString("a_mux", c.audioMuxingMode.name)
            .putInt("countdown", c.countdownSeconds)
            .putBoolean("overlay", c.showFloatingOverlay)
            .putBoolean("stealth", c.stealthOverlay)
            .putString("theme", c.themeId)
            .apply()
    }
}
