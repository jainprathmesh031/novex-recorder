package com.novex.recorder.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** One complete UI palette. Everything in the app reads colours from here. */
data class NovexPalette(
    val id: String,
    val name: String,
    val bgTop: Color,
    val bgBottom: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val border: Color,
    val accent: Color,      // primary brand colour
    val accent2: Color,     // secondary / gradient partner
    val record: Color,      // REC red
    val text: Color,
    val textDim: Color,
    val ok: Color = Color(0xFF3DDC97),
    val warn: Color = Color(0xFFFFB547)
)

object NovexPalettes {
    val VoidViolet = NovexPalette(
        id = "void_violet", name = "Void Violet",
        bgTop = Color(0xFF150C2B), bgBottom = Color(0xFF0A0716),
        surface = Color(0xFF1B1236), surfaceHigh = Color(0xFF261A4A), border = Color(0xFF3A2A6B),
        accent = Color(0xFF9B5CFF), accent2 = Color(0xFFFF2E63), record = Color(0xFFFF2E63),
        text = Color(0xFFF4EEFF), textDim = Color(0xFF9C8FC4)
    )
    val CrimsonStrike = NovexPalette(
        id = "crimson", name = "Crimson Strike",
        bgTop = Color(0xFF241018), bgBottom = Color(0xFF0F070B),
        surface = Color(0xFF2E141E), surfaceHigh = Color(0xFF3F1B29), border = Color(0xFF63293F),
        accent = Color(0xFFFF3B5C), accent2 = Color(0xFFFF8A3D), record = Color(0xFFFF3B5C),
        text = Color(0xFFFFEFF2), textDim = Color(0xFFC79AA6)
    )
    val ToxicVolt = NovexPalette(
        id = "toxic", name = "Toxic Volt",
        bgTop = Color(0xFF0F1A16), bgBottom = Color(0xFF070D0B),
        surface = Color(0xFF14241E), surfaceHigh = Color(0xFF1B3128), border = Color(0xFF2B4F40),
        accent = Color(0xFFC6FF1A), accent2 = Color(0xFF19E6A0), record = Color(0xFFFF3B5C),
        text = Color(0xFFF1FFE8), textDim = Color(0xFF8DB09F)
    )
    val ArcticPulse = NovexPalette(
        id = "arctic", name = "Arctic Pulse",
        bgTop = Color(0xFF0C1B2E), bgBottom = Color(0xFF060E19),
        surface = Color(0xFF112640), surfaceHigh = Color(0xFF173352), border = Color(0xFF265079),
        accent = Color(0xFF2BD9FF), accent2 = Color(0xFF6C7BFF), record = Color(0xFFFF4D6D),
        text = Color(0xFFEAF8FF), textDim = Color(0xFF8AA9C2)
    )
    val SolarGold = NovexPalette(
        id = "gold", name = "Solar Gold",
        bgTop = Color(0xFF211809), bgBottom = Color(0xFF0E0A04),
        surface = Color(0xFF2B1F0B), surfaceHigh = Color(0xFF3A2A0F), border = Color(0xFF65491A),
        accent = Color(0xFFFFC53D), accent2 = Color(0xFFFF7A1A), record = Color(0xFFFF3B3B),
        text = Color(0xFFFFF6E3), textDim = Color(0xFFC2AD82)
    )
    val NeonRush = NovexPalette(
        id = "neon", name = "Neon Rush",
        bgTop = Color(0xFF220A29), bgBottom = Color(0xFF0E0412),
        surface = Color(0xFF2D0F37), surfaceHigh = Color(0xFF3D1549), border = Color(0xFF68247E),
        accent = Color(0xFFFF3DF2), accent2 = Color(0xFF3D7BFF), record = Color(0xFFFF2E63),
        text = Color(0xFFFFEBFD), textDim = Color(0xFFC590CF)
    )

    val all = listOf(VoidViolet, CrimsonStrike, ToxicVolt, ArcticPulse, SolarGold, NeonRush)
    fun byId(id: String): NovexPalette = all.firstOrNull { it.id == id } ?: VoidViolet
}

val LocalNovex = staticCompositionLocalOf { NovexPalettes.VoidViolet }

object Novex {
    val c: NovexPalette
        @Composable get() = LocalNovex.current
}
