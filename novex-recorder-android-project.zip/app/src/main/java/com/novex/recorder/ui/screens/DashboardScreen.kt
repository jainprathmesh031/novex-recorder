package com.novex.recorder.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novex.recorder.R
import com.novex.recorder.data.EncoderCapabilityReport
import com.novex.recorder.data.RecordingConfig
import com.novex.recorder.service.ScreenRecordService.RecordingState
import com.novex.recorder.ui.components.*
import com.novex.recorder.ui.theme.Novex
import kotlinx.coroutines.delay

@Composable
fun DashboardScreen(
    config: RecordingConfig,
    report: EncoderCapabilityReport,
    state: RecordingState,
    elapsedSeconds: Long,
    activePlan: String?,
    micMuted: Boolean,
    internalMuted: Boolean,
    hasOverlayPermission: Boolean,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit,
    onToggleMic: () -> Unit,
    onToggleInternal: () -> Unit,
    onGrantOverlay: () -> Unit,
    onOpenInspector: () -> Unit,
    onOpenInstagram: () -> Unit
) {
    val c = Novex.c
    var countdown by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(countdown) {
        val n = countdown ?: return@LaunchedEffect
        delay(1000)
        if (n > 1) countdown = n - 1 else { countdown = null; onStart() }
    }

    val live = state == RecordingState.RECORDING || state == RecordingState.PAUSED
    val busy = live || state == RecordingState.STARTING || state == RecordingState.STOPPING

    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 1f, targetValue = 1.07f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "scale"
    )

    // Audio tile state: live mute while recording, config toggle otherwise
    val micOn = if (live) !micMuted else config.captureMicAudio
    val sndOn = if (live) !internalMuted else config.captureInternalAudio

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ── Header
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(R.drawable.ic_novex_logo),
                contentDescription = "NØVEX",
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
                    .border(BorderStroke(1.dp, c.accent.copy(alpha = 0.6f)), RoundedCornerShape(14.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("NØVEX", color = c.text, fontWeight = FontWeight.Black, fontSize = 22.sp, letterSpacing = 3.sp)
                Text("RECORDER", style = MaterialTheme.typography.labelSmall, color = c.accent)
            }
            IconButton(
                onClick = onOpenInspector,
                modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(c.surface)
                    .border(BorderStroke(1.dp, c.border), RoundedCornerShape(14.dp))
            ) { Icon(Icons.Rounded.Memory, "Encoder inspector", tint = c.accent) }
        }

        // ── Tagline
        Spacer(Modifier.height(22.dp))
        val brush = Brush.horizontalGradient(listOf(c.accent, c.accent2))
        Column(Modifier.fillMaxWidth()) {
            Text(
                "BUILT FOR",
                style = MaterialTheme.typography.displayLarge.copy(brush = brush),
                fontSize = 50.sp, lineHeight = 48.sp, fontStyle = FontStyle.Italic,
                maxLines = 1, softWrap = false
            )
            Text(
                "WILDS",
                style = MaterialTheme.typography.displayLarge.copy(brush = brush),
                fontSize = 88.sp, lineHeight = 84.sp, fontStyle = FontStyle.Italic,
                maxLines = 1, softWrap = false
            )
        }

        // ── Record orb
        Spacer(Modifier.height(18.dp))
        val ring = if (live) c.record else c.accent
        Box(Modifier.size(230.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(230.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(ring.copy(alpha = if (live) 0.38f else 0.22f), Color.Transparent)))
            )
            Box(
                Modifier.size(196.dp).clip(CircleShape)
                    .border(BorderStroke(2.dp, Brush.sweepGradient(listOf(c.accent, c.accent2, c.accent))), CircleShape)
            )
            Box(
                modifier = Modifier
                    .size(158.dp)
                    .scale(if (state == RecordingState.RECORDING) pulse else 1f)
                    .clip(CircleShape)
                    .background(
                        if (live) Brush.verticalGradient(listOf(c.record, c.record.copy(alpha = 0.7f)))
                        else Brush.verticalGradient(listOf(c.surfaceHigh, c.surface))
                    )
                    .border(BorderStroke(2.dp, ring), CircleShape)
                    .clickable(enabled = state != RecordingState.STARTING && state != RecordingState.STOPPING && countdown == null) {
                        if (live) onStop()
                        else if (config.countdownSeconds > 0) countdown = config.countdownSeconds
                        else onStart()
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    when {
                        countdown != null -> Text("$countdown", color = c.text, fontSize = 64.sp, fontWeight = FontWeight.Black)
                        state == RecordingState.STARTING -> {
                            CircularProgressIndicator(color = c.text, strokeWidth = 3.dp, modifier = Modifier.size(34.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("STARTING", color = c.text, fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = 2.sp)
                        }
                        live -> {
                            Icon(Icons.Rounded.Stop, null, tint = Color.White, modifier = Modifier.size(46.dp))
                            Text(fmt(elapsedSeconds), color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Text(if (state == RecordingState.PAUSED) "PAUSED" else "TAP TO STOP", color = Color.White.copy(alpha = 0.85f), fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                        }
                        else -> {
                            Box(Modifier.size(34.dp).clip(CircleShape).background(Brush.linearGradient(listOf(c.record, c.accent2))))
                            Spacer(Modifier.height(10.dp))
                            Text("START", color = c.text, fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 3.sp)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(
            text = activePlan ?: "${config.resolution.label} • ${config.frameRate} fps requested",
            color = if (activePlan != null) c.ok else c.textDim,
            style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center
        )

        // ── Live controls
        if (live) {
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GradientButton(
                    text = if (state == RecordingState.PAUSED) "RESUME" else "PAUSE",
                    icon = if (state == RecordingState.PAUSED) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                    modifier = Modifier.weight(1f),
                    onClick = { if (state == RecordingState.PAUSED) onResume() else onPause() }
                )
                GradientButton(
                    text = "STOP", icon = Icons.Rounded.Stop, modifier = Modifier.weight(1f),
                    colors = listOf(c.record, c.record.copy(alpha = 0.75f)), onClick = onStop
                )
            }
        }

        // ── Audio sources (live toggles)
        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AudioTile(
                title = "PHONE SOUND", on = sndOn, modifier = Modifier.weight(1f),
                icon = if (sndOn) Icons.Rounded.VolumeUp else Icons.Rounded.VolumeOff, onClick = onToggleInternal
            )
            AudioTile(
                title = "MICROPHONE", on = micOn, modifier = Modifier.weight(1f),
                icon = if (micOn) Icons.Rounded.Mic else Icons.Rounded.MicOff, onClick = onToggleMic
            )
        }

        // ── Stats
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("RESOLUTION", config.resolution.label, Modifier.weight(1f))
            StatTile("FRAME RATE", "${config.frameRate}", Modifier.weight(1f))
            StatTile("BITRATE", if (config.bitrateAuto) "AUTO" else "${config.videoBitrateMbps}M", Modifier.weight(1f))
        }

        if (config.showFloatingOverlay && !hasOverlayPermission) {
            Spacer(Modifier.height(12.dp))
            GlassCard(onClick = onGrantOverlay, padding = 14.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Layers, null, tint = c.warn, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Allow floating controls", color = c.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Tap to grant “display over other apps”", color = c.textDim, fontSize = 11.sp)
                    }
                    Tag("GRANT", c.warn)
                }
            }
        }

        // ── Device line
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(if (report.avcHardware) c.ok else c.warn)
            Spacer(Modifier.width(8.dp))
            Text(
                text = (if (report.isNordCe2Lite) "OnePlus Nord CE 2 Lite" else report.deviceModel) +
                        " • " + (if (report.avcHardware) "hardware encoder" else "software encoder"),
                color = c.textDim, style = MaterialTheme.typography.bodySmall
            )
        }

        // ── Instagram
        Spacer(Modifier.height(18.dp))
        GradientButton(
            text = "FOLLOW @INSIDE.NOVEX", icon = Icons.Rounded.CameraAlt,
            modifier = Modifier.fillMaxWidth(),
            colors = listOf(Color(0xFF833AB4), Color(0xFFFD1D1D), Color(0xFFFCB045)),
            onClick = onOpenInstagram
        )
        Spacer(Modifier.height(8.dp))
        Text("Join the pack on Instagram", color = c.textDim, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun AudioTile(
    title: String, on: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier, onClick: () -> Unit
) {
    val c = Novex.c
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(
                if (on) Brush.linearGradient(listOf(c.accent.copy(alpha = 0.32f), c.accent2.copy(alpha = 0.18f)))
                else Brush.linearGradient(listOf(c.surface, c.surface))
            )
            .border(BorderStroke(1.2.dp, if (on) c.accent else c.border), shape)
            .clickable { onClick() }
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = if (on) c.text else c.record, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(8.dp))
        Text(title, style = MaterialTheme.typography.labelSmall, color = c.textDim)
        Spacer(Modifier.height(4.dp))
        Text(if (on) "ON" else "OFF", color = if (on) c.ok else c.record, fontWeight = FontWeight.Black, fontSize = 16.sp)
    }
}

private fun fmt(sec: Long): String = String.format(java.util.Locale.US, "%02d:%02d", sec / 60, sec % 60)
