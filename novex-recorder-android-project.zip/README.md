# NØVEX Recorder — Built for wilds
Package `com.novex.recorder` · Android 10+ · tuned for OnePlus Nord CE 2 Lite 5G

## Build the APK on GitHub (no PC needed)
1. Unzip this project and upload **everything inside it** to the ROOT of your repo
   (so `settings.gradle.kts`, `app/` and `.github/` sit at the top level).
2. Open the **Actions** tab → *Build NOVEX APK* → *Run workflow* (it also runs on every push).
3. When it finishes, download the artifact **novex-recorder-apk**. Install `app-release.apk`
   (fastest). `app-debug.apk` is a backup.
4. All builds use the same signing key (`novex.keystore`), so new builds install as updates.
   The first time, uninstall any older NØVEX build that was signed with a different key.

## What it does
- 720p / 1080p / 2K / 4K × 30 / 60 / 90 / 120 fps, H.264 or HEVC — nothing is capped by the app.
  Each option is checked against your phone's real encoder; if it can't do the exact mode the app
  steps down only as far as needed. 2K/4K above your 1080p screen are recorded upscaled.
- Orientation Auto / Landscape / Portrait, matched to your screen so videos are never zoomed out.
- Auto or manual bitrate (up to 150 Mbps, clamped to the encoder).
- Phone sound and microphone captured independently — switch each ON/OFF live (app, floating
  controls, notification). Save as separate tracks or one mixed track.
- Premium floating controls (pause / mic / phone sound / stop). Stealth mode collapses them into a
  near-invisible dot so they barely appear in the video; tap the dot to expand.
- 6 switchable UI themes, Instagram button (@inside.novex), no watermark.
- Recordings are saved to Movies/NovexRecorder.

## Notes
- Real fps also depends on the game/app producing frames. Check the Inspector tab for what your
  encoder reports.
- Android draws overlays into screen recordings; stealth mode minimises this but the pill is
  visible for ~3 s after you tap it.
